# Medallion

A **Python-first** agentic AI framework where a Knowledge Graph (KG) is the source of truth. Medallion provides a clean Python API while using Go as the high-performance backend engine.

## 🚀 Quick Start

### Installation

```bash
# Install from source
pip install -e .

# Or install dependencies manually
pip install pyyaml requests
```

### Basic Usage

```python
from medallion import MedallionClient, Workflow, Agent

# Create a client
client = MedallionClient()

# Build a project scaffold
client.build_project("1+4", "my-ai-app")

# Run a workflow
result = client.run_workflow("workflow.yaml", {"question": "What is AI?"})
print(f"Workflow started: {result['run_id']}")
```

### Command Line Interface

```bash
# Generate project scaffold
medallion build 1+4 my-app

# Execute workflow
medallion run workflow.yaml --var question="What is the capital of France?"

# Query knowledge graph
medallion kg query "MATCH (n:Agent) RETURN COUNT(n)"

# Show execution trace
medallion trace --run-id RUN_123
```

## 🏗️ Architecture

- **Python API**: Clean, intuitive interface for AI workflows
- **Go Backend**: High-performance engine for execution and knowledge graph
- **Knowledge Graph**: SQLite-based storage for all agent interactions
- **Provider Agnostic**: Support for Ollama, OpenAI, and other LLM providers
- **Workflow Engine**: DAG-based execution with dependency management

## 📦 Core Components

### MedallionClient
Main interface for interacting with the framework:

```python
from medallion import MedallionClient

client = MedallionClient()
client.build_project("research", "my-research-app")
client.run_workflow("workflow.yaml", {"topic": "AI ethics"})
```

### Workflow Management
Create and manage AI workflows:

```python
from medallion import Workflow, WorkflowStep

workflow = Workflow(
    name="research_paper",
    description="Generate a research paper",
    agents=["researcher", "writer", "reviewer"],
    steps=[
        WorkflowStep("research", "researcher", "{{.topic}}"),
        WorkflowStep("write", "writer", "{{.research.output}}", depends_on=["research"]),
        WorkflowStep("review", "reviewer", "{{.write.output}}", depends_on=["write"])
    ]
)
```

### Agent Configuration
Define AI agents with models and prompts:

```python
from medallion import Agent, ModelConfig

agent = Agent(
    name="researcher",
    type="worker", 
    description="Research specialist",
    model=ModelConfig(provider="ollama", model="llama3.1"),
    prompts={"system": "You are a research expert..."},
    tools=["web_search", "document_retrieval"]
)
```

### Knowledge Graph
Query and inspect the knowledge graph:

```python
from medallion import KnowledgeGraph

kg = KnowledgeGraph()
stats = kg.get_statistics()
agents = kg.get_agents()
claims = kg.get_claims()
```

## 🔧 Development

### Go Backend
```bash
# Build Go binary
make build

# Run tests
make test

# Install locally
make install
```

### Python Package
```bash
# Install in development mode
pip install -e .

# Run Python examples
python examples/python_examples.py

# Run tests
pytest tests/
```

## 📚 Examples

See the `examples/` directory for:
- `research_and_answer/` - Complete research workflow
- `python_examples.py` - Python API usage examples
- `workflow.yaml` - Workflow definitions
- `agents/` - Agent configurations

## 🎯 Key Features

- **Graph-Native Runtime**: Knowledge graph as source of truth
- **Provider Agnostic**: Ollama, OpenAI, and extensible provider system
- **Workflow Orchestration**: DAG-based execution with dependencies
- **Comprehensive Tracing**: Full execution traces with costs and tokens
- **Python-First**: Clean Python API with Go performance backend
- **Project Scaffolding**: Generate complete project structures

## 📄 License

MIT License - see LICENSE file for details.
